module.exports = {
  name: 'Git.exe代理',
  enabled: false,
  tip: '如果你没有安装git命令行则不需要启动它',
  setting: {
    sslVerify: true // 是否关闭sslVerify
  }
}
