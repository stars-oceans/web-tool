// eslint-disable-next-line no-unused-vars
const start = require('./start/index.js')
